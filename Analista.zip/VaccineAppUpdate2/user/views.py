from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Account
from .forms import UserRegisterForm, UserUpdateForm
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
import json
import os
import time
import pathlib
# Create your views here.
def start(request):
    return render(request, 'user/start.html', {'title': ' Start Page'})


def login(request):
    return render(request, 'user/login.html', {'title': 'Login'})


def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Your Account Has Been Created!')
            return redirect('site-user-login')



    else:
        form = UserRegisterForm()
    return render(request, 'user/register.html', {'form': form})




@login_required
def homepage(request):
    {'user': Account.objects.all()

     }
    return render(request, 'user/homepage.html', {'title': 'Homepage'})


@login_required
def editacc(request):
    if request.method == 'POST':

     u_form= UserUpdateForm(request.POST,instance=request.user)
     if u_form.is_valid():
         u_form.save()
         messages.success(request, f'Your Account Has Been Updated!')
         return redirect('site-homepage')
    else:
        u_form = UserUpdateForm( instance=request.user)

    context={
        'u_form':u_form
    }

    return render(request, 'user/editacc.html', {'u_form':u_form})

@login_required
def instrc(request):
    return render(request, 'user/instrc.html', {'title': 'Instructions'})




@login_required
def addkeyword(request):
    return render(request, 'user/KeywordU.html', {'title': 'Add Keyword'})

@login_required
def addfileresults(request):
    return render(request, 'user/Results.html', {'title': 'Results'})


@login_required
def logout(request):
    return render(request, 'user/logout.html', {'title': 'Logout'})


def passreset(request):
    return render(request, 'user/passreset.html', {'title': 'Password Reset'})


def passreset2(request):
    return render(request, 'user/passreset2.html', {'title': 'Password Reset'})

@csrf_exempt
def executemodel(request):
    try:
        import sys
        DIRstart = str(pathlib.Path(__file__).parent.resolve())+'\..\static\\'
        filepath = DIRstart+"Backend.py"
        locals=None
        globals=None
        if globals is None:
            globals = {}
        globals.update({
            "__file__": filepath,
            "__name__": "__main__",
        })
        sys.argv = [filepath, str(request.body)]
        with open(filepath, 'rb') as file:
            exec(compile(file.read(), filepath, 'exec'), globals, locals)
        data = {
                'status': "content"
        }
    except Exception as e:
        print(e)
        data = {
            'status': str(e)
        }
    dump = json.dumps(data)
    return HttpResponse(dump, content_type='application/json')
