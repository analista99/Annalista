from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.contrib import admin
urlpatterns = [


    path('', views.start, name='site-home'),
    path('register/', views.register, name='site-register'),
    path('homepage/', views.homepage, name='site-homepage'),
    path('homepage/editaccount/', views.editacc, name='site-editacc'),
    path('instructions/', views.instrc, name='site-instrc'),
    path('site-execute-model', views.executemodel, name='site-execute-model'),
    path('addfile/Keywords', views.addkeyword, name='site-add-keyword'),
    path('addfile/results', views.addfileresults, name='site-file-results'),
    path('login/', auth_views.LoginView.as_view(template_name='user/login.html'), name='site-user-login'),
    path('logout/',  auth_views.LogoutView.as_view(template_name='user/logout.html'), name='site-user-logout'),
    path('password-reset/enter_email/', auth_views.PasswordResetView.as_view(template_name='user/passreset.html'), name='site-user-passwordreset'),
    path('password-reset/link_sent/', auth_views.PasswordResetDoneView.as_view(template_name='user/passreset2.html'), name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='user/password_reset_confirm.html'),
         name='password_reset_confirm'),
    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(template_name='user/passreset_complete.html'),
         name='password_reset_complete'),

]
urlpatterns += staticfiles_urlpatterns()